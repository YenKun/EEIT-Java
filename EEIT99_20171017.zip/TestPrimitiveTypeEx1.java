package tw.leonchen.myproject.type;

public class TestPrimitiveTypeEx1 {

	public static void main(String[] args) {
		int number;
		number = 6;
		
		System.out.println("number:" + number);
	}

}
