package tw.leonchen.myproject.type;

public class TestPrimitiveTypeEx2 {

	public static void main(String[] args) {
		byte b1 = 15;
		
		char ch1 = 'a';
		char ch2 = 65;
		char ch3 = '\u03C6';
		char ch4 = '\u03A6';
		char ch5 = '\n';
		
		double d1 = 3.14159265358979323846;
		
		System.out.println("b1=" + b1);
		
		System.out.println("ch1=" + ch1);
		System.out.println("ch2=" + ch2);
		System.out.println("ch3=" + ch3);
		System.out.println("ch4=" + ch4);
		System.out.println("ch5=" + ch5);
		
		System.out.println("d1=" + d1);

	}

}
