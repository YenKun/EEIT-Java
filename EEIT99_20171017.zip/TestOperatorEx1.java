package tw.leonchen.myproject.operator;

public class TestOperatorEx1 {

	public static void main(String[] args) {
		int i=1;
        //i=i+1;
		//i++;
		++i;
        System.out.println("i2=" + i);
	}

}
