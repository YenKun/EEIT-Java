package tw.leonchen.myproject.oop;

class Rocket{
	public static void launch() {
		System.out.println("Rocket Launched.");
	}
}

public class TestStaticEx1 {	
	
	public static void main(String[] args) {
		Rocket.launch();
	}

}
