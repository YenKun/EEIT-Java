package tw.leonchen.myproject.type;

public class TestPrimitiveTypeEx3 {

	public static void main(String[] args) {
		final double pi = 3.14;
		//pi=6.28;
		
		System.out.println("pi=" + pi);

	}

}
