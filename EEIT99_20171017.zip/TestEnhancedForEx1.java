package tw.leonchen.myproject.oop.array;

public class TestEnhancedForEx1 {

	public static void main(String[] args) {
		int[] data = {1,2,3,4,5,6,7,8};

		for(int value: data) {
			System.out.println("value:" + value);
		}
	}

}
