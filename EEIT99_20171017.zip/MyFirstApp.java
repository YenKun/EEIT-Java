package tw.leonchen.myproject.common;


/**
 * This is my first java application
 * @author LeonChen(陳奕兆)
 * @version v1.0
 *
 */
public class MyFirstApp {

	/**
	 * This is my java entry point
	 * @param args data
	 */
	public static void main(String[] args) {
		System.out.println("Hola");
	}

}
