package tw.leonchen.myproject.flowcontrol;

public class TestIfEx1 {

	public static void main(String[] args) {
		int degree = 50;
		
		if(degree>=30) {
			System.out.println("Hot");
		}

		System.out.println("Keep Writing Java Forever.");
	}

}
