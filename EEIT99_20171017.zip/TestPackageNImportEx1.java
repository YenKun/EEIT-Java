package tw.leonchen.myproject.oop;

public class TestPackageNImportEx1 {
    public void sayHi() {
    	System.out.println("Buenas Dias.");
    }
    
    public void sayGoodBye() {
    	System.out.println("Husta Luego.");
    }
}
