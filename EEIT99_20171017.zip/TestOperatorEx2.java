package tw.leonchen.myproject.operator;

public class TestOperatorEx2 {

	public static void main(String[] args) {
		int i=1,j;
		//j=i++;
		j=++i;
		
		System.out.println("i=" + i);
        System.out.println("j=" + j);
	}

}
